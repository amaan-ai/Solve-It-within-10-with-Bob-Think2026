      ******************************************************************
      *                                                                *
      * LICENSED MATERIALS - PROPERTY OF IBM                           *
      *                                                                *
      * "RESTRICTED MATERIALS OF IBM"                                  *
      *                                                                *
      * CB12                                                           *
      *                                                                *
      * (C) COPYRIGHT IBM CORP. 2011, 2013 ALL RIGHTS RESERVED         *
      *                                                                *
      * US GOVERNMENT USERS RESTRICTED RIGHTS - USE, DUPLICATION,      *
      * OR DISCLOSURE RESTRICTED BY GSA ADP SCHEDULE                   *
      * CONTRACT WITH IBM CORPORATION                                  *
      *                                                                *
      *                                                                *
      *                    Customer menu                               *
      *                                                                *
      * Menu for Customer transactions                                 *
      *                                                                *
      *                                                                *
      *                                                                *
      ******************************************************************
       IDENTIFICATION DIVISION.
       PROGRAM-ID. LGTESTC1.
       ENVIRONMENT DIVISION.
       CONFIGURATION SECTION.
      *
       DATA DIVISION.
       WORKING-STORAGE SECTION.

       01  WS-RESP                   PIC S9(8) COMP.
       01  WS-Item-Count             PIC S9(4) Comp.
       01  WS-FLAG-TSQH              PIC X.
       01  READ-MSG.
         03 READ-MSG-MSG             PIC X(80).
       01  FILLER REDEFINES Read-MSG.
         03 FILLER                   PIC X(14).
         03 READ-CUST-HIGH           PIC 9(10).
      ******************************
       01  WS-Cust-High              Pic S9(10).
      ******************************

       01  WRITE-MSG.
         03 WRITE-MSG-E            PIC X(20) Value '**** GENAPP CNTL'.
         03 WRITE-MSG-L              PIC X(13) Value 'LOW CUSTOMER='.
         03 WRITE-MSG-LOW            PIC 9(10).
         03 FILLER                   PIC X.
         03 WRITE-MSG-H              PIC X(14) Value 'HIGH CUSTOMER='.
         03 WRITE-MSG-High           PIC 9(10).
       01  STSQ.
         03  STSQ-NAME                 PIC X(8) Value 'GENACNTL'.
      *
       77 F24                        Pic S9(4) Comp Value 24.
       77 MSGEND                       PIC X(24) VALUE
                                        'Transaction ended      '.

      * start of expanded file: C:\data\GenApp\Copybooks\SSMAP.cpy at LGTESTC1.cbl line 57
       01  SSMAPC1I.
           02  FILLER PIC X(12).
           02  ENT1CNOL    COMP  PIC  S9(4).
           02  ENT1CNOF    PICTURE X.
           02  FILLER REDEFINES ENT1CNOF.
             03 ENT1CNOA    PICTURE X.
           02  ENT1CNOI  PIC X(10).
           02  ENT1FNAL    COMP  PIC  S9(4).
           02  ENT1FNAF    PICTURE X.
           02  FILLER REDEFINES ENT1FNAF.
             03 ENT1FNAA    PICTURE X.
           02  ENT1FNAI  PIC X(10).
           02  ENT1LNAL    COMP  PIC  S9(4).
           02  ENT1LNAF    PICTURE X.
           02  FILLER REDEFINES ENT1LNAF.
             03 ENT1LNAA    PICTURE X.
           02  ENT1LNAI  PIC X(20).
           02  ENT1DOBL    COMP  PIC  S9(4).
           02  ENT1DOBF    PICTURE X.
           02  FILLER REDEFINES ENT1DOBF.
             03 ENT1DOBA    PICTURE X.
           02  ENT1DOBI  PIC X(10).
           02  ENT1HNML    COMP  PIC  S9(4).
           02  ENT1HNMF    PICTURE X.
           02  FILLER REDEFINES ENT1HNMF.
             03 ENT1HNMA    PICTURE X.
           02  ENT1HNMI  PIC X(20).
           02  ENT1HNOL    COMP  PIC  S9(4).
           02  ENT1HNOF    PICTURE X.
           02  FILLER REDEFINES ENT1HNOF.
             03 ENT1HNOA    PICTURE X.
           02  ENT1HNOI  PIC X(4).
           02  ENT1HPCL    COMP  PIC  S9(4).
           02  ENT1HPCF    PICTURE X.
           02  FILLER REDEFINES ENT1HPCF.
             03 ENT1HPCA    PICTURE X.
           02  ENT1HPCI  PIC X(8).
           02  ENT1HP1L    COMP  PIC  S9(4).
           02  ENT1HP1F    PICTURE X.
           02  FILLER REDEFINES ENT1HP1F.
             03 ENT1HP1A    PICTURE X.
           02  ENT1HP1I  PIC X(20).
           02  ENT1HP2L    COMP  PIC  S9(4).
           02  ENT1HP2F    PICTURE X.
           02  FILLER REDEFINES ENT1HP2F.
             03 ENT1HP2A    PICTURE X.
           02  ENT1HP2I  PIC X(20).
           02  ENT1HMOL    COMP  PIC  S9(4).
           02  ENT1HMOF    PICTURE X.
           02  FILLER REDEFINES ENT1HMOF.
             03 ENT1HMOA    PICTURE X.
           02  ENT1HMOI  PIC X(27).
           02  ENT1OPTL    COMP  PIC  S9(4).
           02  ENT1OPTF    PICTURE X.
           02  FILLER REDEFINES ENT1OPTF.
             03 ENT1OPTA    PICTURE X.
           02  ENT1OPTI  PIC X(1).
           02  ERRFLDL    COMP  PIC  S9(4).
           02  ERRFLDF    PICTURE X.
           02  FILLER REDEFINES ERRFLDF.
             03 ERRFLDA    PICTURE X.
           02  ERRFLDI  PIC X(40).
       01  SSMAPC1O REDEFINES SSMAPC1I.
           02  FILLER PIC X(12).
           02  FILLER PICTURE X(3).
           02  ENT1CNOO  PIC X(10).
           02  FILLER PICTURE X(3).
           02  ENT1FNAO  PIC X(10).
           02  FILLER PICTURE X(3).
           02  ENT1LNAO  PIC X(20).
           02  FILLER PICTURE X(3).
           02  ENT1DOBO  PIC X(10).
           02  FILLER PICTURE X(3).
           02  ENT1HNMO  PIC X(20).
           02  FILLER PICTURE X(3).
           02  ENT1HNOO  PIC X(4).
           02  FILLER PICTURE X(3).
           02  ENT1HPCO  PIC X(8).
           02  FILLER PICTURE X(3).
           02  ENT1HP1O  PIC X(20).
           02  FILLER PICTURE X(3).
           02  ENT1HP2O  PIC X(20).
           02  FILLER PICTURE X(3).
           02  ENT1HMOO  PIC X(27).
           02  FILLER PICTURE X(3).
           02  ENT1OPTO  PIC X(1).
           02  FILLER PICTURE X(3).
           02  ERRFLDO  PIC X(40).
       01  SSMAPP1I.
           02  FILLER PIC X(12).
           02  ENP1PNOL    COMP  PIC  S9(4).
           02  ENP1PNOF    PICTURE X.
           02  FILLER REDEFINES ENP1PNOF.
             03 ENP1PNOA    PICTURE X.
           02  ENP1PNOI  PIC X(10).
           02  ENP1CNOL    COMP  PIC  S9(4).
           02  ENP1CNOF    PICTURE X.
           02  FILLER REDEFINES ENP1CNOF.
             03 ENP1CNOA    PICTURE X.
           02  ENP1CNOI  PIC X(10).
           02  ENP1IDAL    COMP  PIC  S9(4).
           02  ENP1IDAF    PICTURE X.
           02  FILLER REDEFINES ENP1IDAF.
             03 ENP1IDAA    PICTURE X.
           02  ENP1IDAI  PIC X(10).
           02  ENP1EDAL    COMP  PIC  S9(4).
           02  ENP1EDAF    PICTURE X.
           02  FILLER REDEFINES ENP1EDAF.
             03 ENP1EDAA    PICTURE X.
           02  ENP1EDAI  PIC X(10).
           02  ENP1CMKL    COMP  PIC  S9(4).
           02  ENP1CMKF    PICTURE X.
           02  FILLER REDEFINES ENP1CMKF.
             03 ENP1CMKA    PICTURE X.
           02  ENP1CMKI  PIC X(20).
           02  ENP1CMOL    COMP  PIC  S9(4).
           02  ENP1CMOF    PICTURE X.
           02  FILLER REDEFINES ENP1CMOF.
             03 ENP1CMOA    PICTURE X.
           02  ENP1CMOI  PIC X(20).
           02  ENP1VALL    COMP  PIC  S9(4).
           02  ENP1VALF    PICTURE X.
           02  FILLER REDEFINES ENP1VALF.
             03 ENP1VALA    PICTURE X.
           02  ENP1VALI  PIC X(6).
           02  ENP1REGL    COMP  PIC  S9(4).
           02  ENP1REGF    PICTURE X.
           02  FILLER REDEFINES ENP1REGF.
             03 ENP1REGA    PICTURE X.
           02  ENP1REGI  PIC X(7).
           02  ENP1COLL    COMP  PIC  S9(4).
           02  ENP1COLF    PICTURE X.
           02  FILLER REDEFINES ENP1COLF.
             03 ENP1COLA    PICTURE X.
           02  ENP1COLI  PIC X(8).
           02  ENP1CCL    COMP  PIC  S9(4).
           02  ENP1CCF    PICTURE X.
           02  FILLER REDEFINES ENP1CCF.
             03 ENP1CCA    PICTURE X.
           02  ENP1CCI  PIC X(8).
           02  ENP1MANL    COMP  PIC  S9(4).
           02  ENP1MANF    PICTURE X.
           02  FILLER REDEFINES ENP1MANF.
             03 ENP1MANA    PICTURE X.
           02  ENP1MANI  PIC X(10).
           02  ENP1ACCL    COMP  PIC  S9(4).
           02  ENP1ACCF    PICTURE X.
           02  FILLER REDEFINES ENP1ACCF.
             03 ENP1ACCA    PICTURE X.
           02  ENP1ACCI  PIC X(6).
           02  ENP1PREL    COMP  PIC  S9(4).
           02  ENP1PREF    PICTURE X.
           02  FILLER REDEFINES ENP1PREF.
             03 ENP1PREA    PICTURE X.
           02  ENP1PREI  PIC X(6).
           02  ENP1OPTL    COMP  PIC  S9(4).
           02  ENP1OPTF    PICTURE X.
           02  FILLER REDEFINES ENP1OPTF.
             03 ENP1OPTA    PICTURE X.
           02  ENP1OPTI  PIC X(1).
           02  ERP1FLDL    COMP  PIC  S9(4).
           02  ERP1FLDF    PICTURE X.
           02  FILLER REDEFINES ERP1FLDF.
             03 ERP1FLDA    PICTURE X.
           02  ERP1FLDI  PIC X(40).
       01  SSMAPP1O REDEFINES SSMAPP1I.
           02  FILLER PIC X(12).
           02  FILLER PICTURE X(3).
           02  ENP1PNOO  PIC X(10).
           02  FILLER PICTURE X(3).
           02  ENP1CNOO  PIC X(10).
           02  FILLER PICTURE X(3).
           02  ENP1IDAO  PIC X(10).
           02  FILLER PICTURE X(3).
           02  ENP1EDAO  PIC X(10).
           02  FILLER PICTURE X(3).
           02  ENP1CMKO  PIC X(20).
           02  FILLER PICTURE X(3).
           02  ENP1CMOO  PIC X(20).
           02  FILLER PICTURE X(3).
           02  ENP1VALO  PIC X(6).
           02  FILLER PICTURE X(3).
           02  ENP1REGO  PIC X(7).
           02  FILLER PICTURE X(3).
           02  ENP1COLO  PIC X(8).
           02  FILLER PICTURE X(3).
           02  ENP1CCO  PIC X(8).
           02  FILLER PICTURE X(3).
           02  ENP1MANO  PIC X(10).
           02  FILLER PICTURE X(3).
           02  ENP1ACCO  PIC X(6).
           02  FILLER PICTURE X(3).
           02  ENP1PREO  PIC X(6).
           02  FILLER PICTURE X(3).
           02  ENP1OPTO  PIC X(1).
           02  FILLER PICTURE X(3).
           02  ERP1FLDO  PIC X(40).
       01  SSMAPP2I.
           02  FILLER PIC X(12).
           02  ENP2PNOL    COMP  PIC  S9(4).
           02  ENP2PNOF    PICTURE X.
           02  FILLER REDEFINES ENP2PNOF.
             03 ENP2PNOA    PICTURE X.
           02  ENP2PNOI  PIC X(10).
           02  ENP2CNOL    COMP  PIC  S9(4).
           02  ENP2CNOF    PICTURE X.
           02  FILLER REDEFINES ENP2CNOF.
             03 ENP2CNOA    PICTURE X.
           02  ENP2CNOI  PIC X(10).
           02  ENP2IDAL    COMP  PIC  S9(4).
           02  ENP2IDAF    PICTURE X.
           02  FILLER REDEFINES ENP2IDAF.
             03 ENP2IDAA    PICTURE X.
           02  ENP2IDAI  PIC X(10).
           02  ENP2EDAL    COMP  PIC  S9(4).
           02  ENP2EDAF    PICTURE X.
           02  FILLER REDEFINES ENP2EDAF.
             03 ENP2EDAA    PICTURE X.
           02  ENP2EDAI  PIC X(10).
           02  ENP2FNML    COMP  PIC  S9(4).
           02  ENP2FNMF    PICTURE X.
           02  FILLER REDEFINES ENP2FNMF.
             03 ENP2FNMA    PICTURE X.
           02  ENP2FNMI  PIC X(10).
           02  ENP2TERL    COMP  PIC  S9(4).
           02  ENP2TERF    PICTURE X.
           02  FILLER REDEFINES ENP2TERF.
             03 ENP2TERA    PICTURE X.
           02  ENP2TERI  PIC X(2).
           02  ENP2SUML    COMP  PIC  S9(4).
           02  ENP2SUMF    PICTURE X.
           02  FILLER REDEFINES ENP2SUMF.
             03 ENP2SUMA    PICTURE X.
           02  ENP2SUMI  PIC X(6).
           02  ENP2LIFL    COMP  PIC  S9(4).
           02  ENP2LIFF    PICTURE X.
           02  FILLER REDEFINES ENP2LIFF.
             03 ENP2LIFA    PICTURE X.
           02  ENP2LIFI  PIC X(25).
           02  ENP2WPRL    COMP  PIC  S9(4).
           02  ENP2WPRF    PICTURE X.
           02  FILLER REDEFINES ENP2WPRF.
             03 ENP2WPRA    PICTURE X.
           02  ENP2WPRI  PIC X(1).
           02  ENP2EQUL    COMP  PIC  S9(4).
           02  ENP2EQUF    PICTURE X.
           02  FILLER REDEFINES ENP2EQUF.
             03 ENP2EQUA    PICTURE X.
           02  ENP2EQUI  PIC X(1).
           02  ENP2MANL    COMP  PIC  S9(4).
           02  ENP2MANF    PICTURE X.
           02  FILLER REDEFINES ENP2MANF.
             03 ENP2MANA    PICTURE X.
           02  ENP2MANI  PIC X(1).
           02  ENP2OPTL    COMP  PIC  S9(4).
           02  ENP2OPTF    PICTURE X.
           02  FILLER REDEFINES ENP2OPTF.
             03 ENP2OPTA    PICTURE X.
           02  ENP2OPTI  PIC X(1).
           02  ERP2FLDL    COMP  PIC  S9(4).
           02  ERP2FLDF    PICTURE X.
           02  FILLER REDEFINES ERP2FLDF.
             03 ERP2FLDA    PICTURE X.
           02  ERP2FLDI  PIC X(40).
       01  SSMAPP2O REDEFINES SSMAPP2I.
           02  FILLER PIC X(12).
           02  FILLER PICTURE X(3).
           02  ENP2PNOO  PIC X(10).
           02  FILLER PICTURE X(3).
           02  ENP2CNOO  PIC X(10).
           02  FILLER PICTURE X(3).
           02  ENP2IDAO  PIC X(10).
           02  FILLER PICTURE X(3).
           02  ENP2EDAO  PIC X(10).
           02  FILLER PICTURE X(3).
           02  ENP2FNMO  PIC X(10).
           02  FILLER PICTURE X(3).
           02  ENP2TERO  PIC X(2).
           02  FILLER PICTURE X(3).
           02  ENP2SUMO  PIC X(6).
           02  FILLER PICTURE X(3).
           02  ENP2LIFO  PIC X(25).
           02  FILLER PICTURE X(3).
           02  ENP2WPRO  PIC X(1).
           02  FILLER PICTURE X(3).
           02  ENP2EQUO  PIC X(1).
           02  FILLER PICTURE X(3).
           02  ENP2MANO  PIC X(1).
           02  FILLER PICTURE X(3).
           02  ENP2OPTO  PIC X(1).
           02  FILLER PICTURE X(3).
           02  ERP2FLDO  PIC X(40).
       01  SSMAPP3I.
           02  FILLER PIC X(12).
           02  ENP3PNOL    COMP  PIC  S9(4).
           02  ENP3PNOF    PICTURE X.
           02  FILLER REDEFINES ENP3PNOF.
             03 ENP3PNOA    PICTURE X.
           02  ENP3PNOI  PIC X(10).
           02  ENP3CNOL    COMP  PIC  S9(4).
           02  ENP3CNOF    PICTURE X.
           02  FILLER REDEFINES ENP3CNOF.
             03 ENP3CNOA    PICTURE X.
           02  ENP3CNOI  PIC X(10).
           02  ENP3IDAL    COMP  PIC  S9(4).
           02  ENP3IDAF    PICTURE X.
           02  FILLER REDEFINES ENP3IDAF.
             03 ENP3IDAA    PICTURE X.
           02  ENP3IDAI  PIC X(10).
           02  ENP3EDAL    COMP  PIC  S9(4).
           02  ENP3EDAF    PICTURE X.
           02  FILLER REDEFINES ENP3EDAF.
             03 ENP3EDAA    PICTURE X.
           02  ENP3EDAI  PIC X(10).
           02  ENP3TYPL    COMP  PIC  S9(4).
           02  ENP3TYPF    PICTURE X.
           02  FILLER REDEFINES ENP3TYPF.
             03 ENP3TYPA    PICTURE X.
           02  ENP3TYPI  PIC X(15).
           02  ENP3BEDL    COMP  PIC  S9(4).
           02  ENP3BEDF    PICTURE X.
           02  FILLER REDEFINES ENP3BEDF.
             03 ENP3BEDA    PICTURE X.
           02  ENP3BEDI  PIC X(3).
           02  ENP3VALL    COMP  PIC  S9(4).
           02  ENP3VALF    PICTURE X.
           02  FILLER REDEFINES ENP3VALF.
             03 ENP3VALA    PICTURE X.
           02  ENP3VALI  PIC X(8).
           02  ENP3HNML    COMP  PIC  S9(4).
           02  ENP3HNMF    PICTURE X.
           02  FILLER REDEFINES ENP3HNMF.
             03 ENP3HNMA    PICTURE X.
           02  ENP3HNMI  PIC X(20).
           02  ENP3HNOL    COMP  PIC  S9(4).
           02  ENP3HNOF    PICTURE X.
           02  FILLER REDEFINES ENP3HNOF.
             03 ENP3HNOA    PICTURE X.
           02  ENP3HNOI  PIC X(4).
           02  ENP3HPCL    COMP  PIC  S9(4).
           02  ENP3HPCF    PICTURE X.
           02  FILLER REDEFINES ENP3HPCF.
             03 ENP3HPCA    PICTURE X.
           02  ENP3HPCI  PIC X(8).
           02  ENP3OPTL    COMP  PIC  S9(4).
           02  ENP3OPTF    PICTURE X.
           02  FILLER REDEFINES ENP3OPTF.
             03 ENP3OPTA    PICTURE X.
           02  ENP3OPTI  PIC X(1).
           02  ERP3FLDL    COMP  PIC  S9(4).
           02  ERP3FLDF    PICTURE X.
           02  FILLER REDEFINES ERP3FLDF.
             03 ERP3FLDA    PICTURE X.
           02  ERP3FLDI  PIC X(40).
       01  SSMAPP3O REDEFINES SSMAPP3I.
           02  FILLER PIC X(12).
           02  FILLER PICTURE X(3).
           02  ENP3PNOO  PIC X(10).
           02  FILLER PICTURE X(3).
           02  ENP3CNOO  PIC X(10).
           02  FILLER PICTURE X(3).
           02  ENP3IDAO  PIC X(10).
           02  FILLER PICTURE X(3).
           02  ENP3EDAO  PIC X(10).
           02  FILLER PICTURE X(3).
           02  ENP3TYPO  PIC X(15).
           02  FILLER PICTURE X(3).
           02  ENP3BEDO  PIC X(3).
           02  FILLER PICTURE X(3).
           02  ENP3VALO  PIC X(8).
           02  FILLER PICTURE X(3).
           02  ENP3HNMO  PIC X(20).
           02  FILLER PICTURE X(3).
           02  ENP3HNOO  PIC X(4).
           02  FILLER PICTURE X(3).
           02  ENP3HPCO  PIC X(8).
           02  FILLER PICTURE X(3).
           02  ENP3OPTO  PIC X(1).
           02  FILLER PICTURE X(3).
           02  ERP3FLDO  PIC X(40).
       01  SSMAPP4I.
           02  FILLER PIC X(12).
           02  ENP4PNOL    COMP  PIC  S9(4).
           02  ENP4PNOF    PICTURE X.
           02  FILLER REDEFINES ENP4PNOF.
             03 ENP4PNOA    PICTURE X.
           02  ENP4PNOI  PIC X(10).
           02  ENP4CNOL    COMP  PIC  S9(4).
           02  ENP4CNOF    PICTURE X.
           02  FILLER REDEFINES ENP4CNOF.
             03 ENP4CNOA    PICTURE X.
           02  ENP4CNOI  PIC X(10).
           02  ENP4IDAL    COMP  PIC  S9(4).
           02  ENP4IDAF    PICTURE X.
           02  FILLER REDEFINES ENP4IDAF.
             03 ENP4IDAA    PICTURE X.
           02  ENP4IDAI  PIC X(10).
           02  ENP4EDAL    COMP  PIC  S9(4).
           02  ENP4EDAF    PICTURE X.
           02  FILLER REDEFINES ENP4EDAF.
             03 ENP4EDAA    PICTURE X.
           02  ENP4EDAI  PIC X(10).
           02  ENP4ADDL    COMP  PIC  S9(4).
           02  ENP4ADDF    PICTURE X.
           02  FILLER REDEFINES ENP4ADDF.
             03 ENP4ADDA    PICTURE X.
           02  ENP4ADDI  PIC X(25).
           02  ENP4HPCL    COMP  PIC  S9(4).
           02  ENP4HPCF    PICTURE X.
           02  FILLER REDEFINES ENP4HPCF.
             03 ENP4HPCA    PICTURE X.
           02  ENP4HPCI  PIC X(8).
           02  ENP4LATL    COMP  PIC  S9(4).
           02  ENP4LATF    PICTURE X.
           02  FILLER REDEFINES ENP4LATF.
             03 ENP4LATA    PICTURE X.
           02  ENP4LATI  PIC X(11).
           02  ENP4LONL    COMP  PIC  S9(4).
           02  ENP4LONF    PICTURE X.
           02  FILLER REDEFINES ENP4LONF.
             03 ENP4LONA    PICTURE X.
           02  ENP4LONI  PIC X(11).
           02  ENP4CUSL    COMP  PIC  S9(4).
           02  ENP4CUSF    PICTURE X.
           02  FILLER REDEFINES ENP4CUSF.
             03 ENP4CUSA    PICTURE X.
           02  ENP4CUSI  PIC X(25).
           02  ENP4PTYL    COMP  PIC  S9(4).
           02  ENP4PTYF    PICTURE X.
           02  FILLER REDEFINES ENP4PTYF.
             03 ENP4PTYA    PICTURE X.
           02  ENP4PTYI  PIC X(25).
           02  ENP4FPEL    COMP  PIC  S9(4).
           02  ENP4FPEF    PICTURE X.
           02  FILLER REDEFINES ENP4FPEF.
             03 ENP4FPEA    PICTURE X.
           02  ENP4FPEI  PIC X(4).
           02  ENP4FPRL    COMP  PIC  S9(4).
           02  ENP4FPRF    PICTURE X.
           02  FILLER REDEFINES ENP4FPRF.
             03 ENP4FPRA    PICTURE X.
           02  ENP4FPRI  PIC X(8).
           02  ENP4CPEL    COMP  PIC  S9(4).
           02  ENP4CPEF    PICTURE X.
           02  FILLER REDEFINES ENP4CPEF.
             03 ENP4CPEA    PICTURE X.
           02  ENP4CPEI  PIC X(4).
           02  ENP4CPRL    COMP  PIC  S9(4).
           02  ENP4CPRF    PICTURE X.
           02  FILLER REDEFINES ENP4CPRF.
             03 ENP4CPRA    PICTURE X.
           02  ENP4CPRI  PIC X(8).
           02  ENP4XPEL    COMP  PIC  S9(4).
           02  ENP4XPEF    PICTURE X.
           02  FILLER REDEFINES ENP4XPEF.
             03 ENP4XPEA    PICTURE X.
           02  ENP4XPEI  PIC X(4).
           02  ENP4XPRL    COMP  PIC  S9(4).
           02  ENP4XPRF    PICTURE X.
           02  FILLER REDEFINES ENP4XPRF.
             03 ENP4XPRA    PICTURE X.
           02  ENP4XPRI  PIC X(8).
           02  ENP4WPEL    COMP  PIC  S9(4).
           02  ENP4WPEF    PICTURE X.
           02  FILLER REDEFINES ENP4WPEF.
             03 ENP4WPEA    PICTURE X.
           02  ENP4WPEI  PIC X(4).
           02  ENP4WPRL    COMP  PIC  S9(4).
           02  ENP4WPRF    PICTURE X.
           02  FILLER REDEFINES ENP4WPRF.
             03 ENP4WPRA    PICTURE X.
           02  ENP4WPRI  PIC X(8).
           02  ENP4STAL    COMP  PIC  S9(4).
           02  ENP4STAF    PICTURE X.
           02  FILLER REDEFINES ENP4STAF.
             03 ENP4STAA    PICTURE X.
           02  ENP4STAI  PIC X(4).
           02  ENP4REJL    COMP  PIC  S9(4).
           02  ENP4REJF    PICTURE X.
           02  FILLER REDEFINES ENP4REJF.
             03 ENP4REJA    PICTURE X.
           02  ENP4REJI  PIC X(25).
           02  ENP4OPTL    COMP  PIC  S9(4).
           02  ENP4OPTF    PICTURE X.
           02  FILLER REDEFINES ENP4OPTF.
             03 ENP4OPTA    PICTURE X.
           02  ENP4OPTI  PIC X(1).
           02  ERP4FLDL    COMP  PIC  S9(4).
           02  ERP4FLDF    PICTURE X.
           02  FILLER REDEFINES ERP4FLDF.
             03 ERP4FLDA    PICTURE X.
           02  ERP4FLDI  PIC X(40).
       01  SSMAPP4O REDEFINES SSMAPP4I.
           02  FILLER PIC X(12).
           02  FILLER PICTURE X(3).
           02  ENP4PNOO  PIC X(10).
           02  FILLER PICTURE X(3).
           02  ENP4CNOO  PIC X(10).
           02  FILLER PICTURE X(3).
           02  ENP4IDAO  PIC X(10).
           02  FILLER PICTURE X(3).
           02  ENP4EDAO  PIC X(10).
           02  FILLER PICTURE X(3).
           02  ENP4ADDO  PIC X(25).
           02  FILLER PICTURE X(3).
           02  ENP4HPCO  PIC X(8).
           02  FILLER PICTURE X(3).
           02  ENP4LATO  PIC X(11).
           02  FILLER PICTURE X(3).
           02  ENP4LONO  PIC X(11).
           02  FILLER PICTURE X(3).
           02  ENP4CUSO  PIC X(25).
           02  FILLER PICTURE X(3).
           02  ENP4PTYO  PIC X(25).
           02  FILLER PICTURE X(3).
           02  ENP4FPEO  PIC X(4).
           02  FILLER PICTURE X(3).
           02  ENP4FPRO  PIC X(8).
           02  FILLER PICTURE X(3).
           02  ENP4CPEO  PIC X(4).
           02  FILLER PICTURE X(3).
           02  ENP4CPRO  PIC X(8).
           02  FILLER PICTURE X(3).
           02  ENP4XPEO  PIC X(4).
           02  FILLER PICTURE X(3).
           02  ENP4XPRO  PIC X(8).
           02  FILLER PICTURE X(3).
           02  ENP4WPEO  PIC X(4).
           02  FILLER PICTURE X(3).
           02  ENP4WPRO  PIC X(8).
           02  FILLER PICTURE X(3).
           02  ENP4STAO  PIC X(4).
           02  FILLER PICTURE X(3).
           02  ENP4REJO  PIC X(25).
           02  FILLER PICTURE X(3).
           02  ENP4OPTO  PIC X(1).
           02  FILLER PICTURE X(3).
           02  ERP4FLDO  PIC X(40).
       01  SSMAPP5I.
           02  FILLER PIC X(12).
           02  ENP5LNOL    COMP  PIC  S9(4).
           02  ENP5LNOF    PICTURE X.
           02  FILLER REDEFINES ENP5LNOF.
             03 ENP5LNOA    PICTURE X.
           02  ENP5LNOI  PIC X(10).
           02  ENP5PNOL    COMP  PIC  S9(4).
           02  ENP5PNOF    PICTURE X.
           02  FILLER REDEFINES ENP5PNOF.
             03 ENP5PNOA    PICTURE X.
           02  ENP5PNOI  PIC X(10).
           02  ENP5CNOL    COMP  PIC  S9(4).
           02  ENP5CNOF    PICTURE X.
           02  FILLER REDEFINES ENP5CNOF.
             03 ENP5CNOA    PICTURE X.
           02  ENP5CNOI  PIC X(10).
           02  ENP5CDAL    COMP  PIC  S9(4).
           02  ENP5CDAF    PICTURE X.
           02  FILLER REDEFINES ENP5CDAF.
             03 ENP5CDAA    PICTURE X.
           02  ENP5CDAI  PIC X(10).
           02  ENP5PADL    COMP  PIC  S9(4).
           02  ENP5PADF    PICTURE X.
           02  FILLER REDEFINES ENP5PADF.
             03 ENP5PADA    PICTURE X.
           02  ENP5PADI  PIC X(10).
           02  ENP5VALL    COMP  PIC  S9(4).
           02  ENP5VALF    PICTURE X.
           02  FILLER REDEFINES ENP5VALF.
             03 ENP5VALA    PICTURE X.
           02  ENP5VALI  PIC X(10).
           02  ENP5CAUL    COMP  PIC  S9(4).
           02  ENP5CAUF    PICTURE X.
           02  FILLER REDEFINES ENP5CAUF.
             03 ENP5CAUA    PICTURE X.
           02  ENP5CAUI  PIC X(25).
           02  ENP5OBSL    COMP  PIC  S9(4).
           02  ENP5OBSF    PICTURE X.
           02  FILLER REDEFINES ENP5OBSF.
             03 ENP5OBSA    PICTURE X.
           02  ENP5OBSI  PIC X(25).
           02  ENP5OPTL    COMP  PIC  S9(4).
           02  ENP5OPTF    PICTURE X.
           02  FILLER REDEFINES ENP5OPTF.
             03 ENP5OPTA    PICTURE X.
           02  ENP5OPTI  PIC X(1).
           02  ERP5FLDL    COMP  PIC  S9(4).
           02  ERP5FLDF    PICTURE X.
           02  FILLER REDEFINES ERP5FLDF.
             03 ERP5FLDA    PICTURE X.
           02  ERP5FLDI  PIC X(40).
       01  SSMAPP5O REDEFINES SSMAPP5I.
           02  FILLER PIC X(12).
           02  FILLER PICTURE X(3).
           02  ENP5LNOO  PIC X(10).
           02  FILLER PICTURE X(3).
           02  ENP5PNOO  PIC X(10).
           02  FILLER PICTURE X(3).
           02  ENP5CNOO  PIC X(10).
           02  FILLER PICTURE X(3).
           02  ENP5CDAO  PIC X(10).
           02  FILLER PICTURE X(3).
           02  ENP5PADO  PIC X(10).
           02  FILLER PICTURE X(3).
           02  ENP5VALO  PIC X(10).
           02  FILLER PICTURE X(3).
           02  ENP5CAUO  PIC X(25).
           02  FILLER PICTURE X(3).
           02  ENP5OBSO  PIC X(25).
           02  FILLER PICTURE X(3).
           02  ENP5OPTO  PIC X(1).
           02  FILLER PICTURE X(3).
           02  ERP5FLDO  PIC X(40).
      * end of expanded file: C:\data\GenApp\Copybooks\SSMAP.cpy at LGTESTC1.cbl line 57
        01 COMM-AREA.
      * start of expanded file: C:\data\GenApp\PublicCopybooks\LGCMAREA.cpy at LGTESTC1.cbl line 59
      ******************************************************************
      *                                                                *
      * LICENSED MATERIALS - PROPERTY OF IBM                           *
      *                                                                *
      * "RESTRICTED MATERIALS OF IBM"                                  *
      *                                                                *
      * CB12                                                           *
      *                                                                *
      * (C) COPYRIGHT IBM CORP. 2011, 2013 ALL RIGHTS RESERVED         *
      *                                                                *
      * US GOVERNMENT USERS RESTRICTED RIGHTS - USE, DUPLICATION,      *
      * OR DISCLOSURE RESTRICTED BY GSA ADP SCHEDULE                   *
      * CONTRACT WITH IBM CORPORATION                                  *
      *                                                                *
      *                                                                *
      *               COPYBOOK for COMMAREA structure                  *
      *                                                                *
      *   This commarea can be used for all functions                  *
      *                                                                *
      *                                                                *
      *                                                                *
      ******************************************************************
           03 CA-REQUEST-ID            PIC X(6).
           03 CA-RETURN-CODE           PIC 9(2).
           03 CA-CUSTOMER-NUM          PIC 9(10).
           03 CA-REQUEST-SPECIFIC      PIC X(32482).
      *    Fields used in INQ All and ADD customer
           03 CA-CUSTOMER-REQUEST REDEFINES CA-REQUEST-SPECIFIC.
              05 CA-FIRST-NAME         PIC X(10).
              05 CA-LAST-NAME          PIC X(20).
              05 CA-DOB                PIC X(10).
              05 CA-HOUSE-NAME         PIC X(20).
              05 CA-HOUSE-NUM          PIC X(4).
              05 CA-POSTCODE           PIC X(8).
              05 CA-NUM-POLICIES       PIC 9(3).
              05 CA-PHONE-MOBILE       PIC X(20).
              05 CA-PHONE-HOME         PIC X(20).
              05 CA-EMAIL-ADDRESS      PIC X(100).
              05 CA-POLICY-DATA        PIC X(32267).
      *    Fields used in Customer security call
           03 CA-CUSTSECR-REQUEST REDEFINES CA-REQUEST-SPECIFIC.
              05 CA-CUSTSECR-PASS      PIC X(32).
              05 CA-CUSTSECR-COUNT     PIC X(4).
              05 CA-CUSTSECR-STATE     PIC X.
              05 CA-CUSTSECR-DATA      PIC X(32445).
      *    Fields used in INQ, UPD, ADD & DELETE policy
           03 CA-POLICY-REQUEST REDEFINES CA-REQUEST-SPECIFIC.
              05 CA-POLICY-NUM         PIC 9(10).
      *       Common policy details
              05 CA-POLICY-COMMON.
                 07 CA-ISSUE-DATE      PIC X(10).
                 07 CA-EXPIRY-DATE     PIC X(10).
                 07 CA-LASTCHANGED     PIC X(26).
                 07 CA-BROKERID        PIC 9(10).
                 07 CA-BROKERSREF      PIC X(10).
                 07 CA-PAYMENT         PIC 9(6).
              05 CA-POLICY-SPECIFIC    PIC X(32400).
      *       Endowment policy description
              05 CA-ENDOWMENT REDEFINES CA-POLICY-SPECIFIC.
                 07 CA-E-WITH-PROFITS    PIC X.
                 07 CA-E-EQUITIES        PIC X.
                 07 CA-E-MANAGED-FUND    PIC X.
                 07 CA-E-FUND-NAME       PIC X(10).
                 07 CA-E-TERM            PIC 99.
                 07 CA-E-SUM-ASSURED     PIC 9(6).
                 07 CA-E-LIFE-ASSURED    PIC X(31).
                 07 CA-E-PADDING-DATA    PIC X(32348).
      *       House policy description
              05 CA-HOUSE REDEFINES CA-POLICY-SPECIFIC.
                 07 CA-H-PROPERTY-TYPE   PIC X(15).
                 07 CA-H-BEDROOMS        PIC 9(3).
                 07 CA-H-VALUE           PIC 9(8).
                 07 CA-H-HOUSE-NAME      PIC X(20).
                 07 CA-H-HOUSE-NUMBER    PIC X(4).
                 07 CA-H-POSTCODE        PIC X(8).
                 07 CA-H-FILLER          PIC X(32342).
      *       Motor policy description
              05 CA-MOTOR REDEFINES CA-POLICY-SPECIFIC.
                 07 CA-M-MAKE            PIC X(15).
                 07 CA-M-MODEL           PIC X(15).
                 07 CA-M-VALUE           PIC 9(6).
                 07 CA-M-REGNUMBER       PIC X(7).
                 07 CA-M-COLOUR          PIC X(8).
                 07 CA-M-CC              PIC 9(4).
                 07 CA-M-MANUFACTURED    PIC X(10).
                 07 CA-M-PREMIUM         PIC 9(6).
                 07 CA-M-ACCIDENTS       PIC 9(6).
                 07 CA-M-FILLER          PIC X(32323).
      *       Commercial policy description
              05 CA-COMMERCIAL REDEFINES CA-POLICY-SPECIFIC.
                 07 CA-B-Address         PIC X(255).
                 07 CA-B-Postcode        PIC X(8).
                 07 CA-B-Latitude        PIC X(11).
                 07 CA-B-Longitude       PIC X(11).
                 07 CA-B-Customer        PIC X(255).
                 07 CA-B-PropType        PIC X(255).
                 07 CA-B-FirePeril       PIC 9(4).
                 07 CA-B-FirePremium     PIC 9(8).
                 07 CA-B-CrimePeril      PIC 9(4).
                 07 CA-B-CrimePremium    PIC 9(8).
                 07 CA-B-FloodPeril      PIC 9(4).
                 07 CA-B-FloodPremium    PIC 9(8).
                 07 CA-B-WeatherPeril    PIC 9(4).
                 07 CA-B-WeatherPremium  PIC 9(8).
                 07 CA-B-Status          PIC 9(4).
                 07 CA-B-RejectReason    PIC X(255).
                 07 CA-B-FILLER          PIC X(31298).
      *       CLAIM policy description
              05 CA-CLAIM      REDEFINES CA-POLICY-SPECIFIC.
                 07 CA-C-Num             PIC 9(10).
                 07 CA-C-Date            PIC X(10).
                 07 CA-C-Paid            PIC 9(8).
                 07 CA-C-Value           PIC 9(8).
                 07 CA-C-Cause           PIC X(255).
                 07 CA-C-Observations    PIC X(255).
                 07 CA-C-FILLER          PIC X(31854).
      * end of expanded file: C:\data\GenApp\PublicCopybooks\LGCMAREA.cpy at LGTESTC1.cbl line 59


      *----------------------------------------------------------------*
      * Common defintions                                              *
      *----------------------------------------------------------------*
      * Run time (debug) infomation for this invocation
        01  WS-HEADER.
           03 WS-EYECATCHER            PIC X(16)
                                        VALUE 'LGICUS01------WS'.
           03 WS-TRANSID               PIC X(4).
           03 WS-TERMID                PIC X(4).
           03 WS-TASKNUM               PIC 9(7).
           03 WS-FILLER                PIC X.
           03 WS-ADDR-DFHCOMMAREA      USAGE is POINTER.
           03 WS-CALEN                 PIC S9(4) COMP.

      * Variables for time/date processing
       01  WS-ABSTIME                  PIC S9(8) COMP VALUE +0.
       01  WS-TIME                     PIC X(8)  VALUE SPACES.
       01  WS-DATE                     PIC X(10) VALUE SPACES.

      * Error Message structure
       01  ERROR-MSG.
           03 EM-DATE                  PIC X(8)  VALUE SPACES.
           03 FILLER                   PIC X     VALUE SPACES.
           03 EM-TIME                  PIC X(6)  VALUE SPACES.
           03 FILLER                   PIC X(9)  VALUE ' LGICUS01'.
           03 EM-VARIABLE.
             05 FILLER                 PIC X(6)  VALUE ' CNUM='.
             05 EM-CUSNUM              PIC X(10)  VALUE SPACES.
             05 FILLER                 PIC X(6)  VALUE ' PNUM='.
             05 EM-POLNUM              PIC X(10)  VALUE SPACES.
             05 EM-SQLREQ              PIC X(16) VALUE SPACES.
             05 FILLER                 PIC X(9)  VALUE ' SQLCODE='.
             05 EM-SQLRC               PIC +9(5) USAGE DISPLAY.

       01 CA-ERROR-MSG.
           03 FILLER                PIC X(9)  VALUE 'COMMAREA='.
           03 CA-DATA               PIC X(90) VALUE SPACES.

       01 LGICDB01                  PIC x(8) Value 'LGICDB01'.
       01  ATRANID                     PIC X(4)       VALUE 'DSC1'.
      *----------------------------------------------------------------*
      * Fields to be used to calculate if commarea is large enough
       01  WS-COMMAREA-LENGTHS.
           03 WS-CA-HEADERTRAILER-LEN  PIC S9(4) COMP VALUE +18.
           03 WS-REQUIRED-CA-LEN       PIC S9(4)      VALUE +0.

       01  MQ-Hit                      PIC S9(4).
       01  MQ-Read-Record              PIC X(80).
       77  MQ-Control                  Pic X(8) Value 'GENAWMQC'.

      * start of expanded file: C:\data\GenApp\Copybooks\LGPOLICY.cpy at LGTESTC1.cbl line 112
      ******************************************************************
      *                                                                *
      * LICENSED MATERIALS - PROPERTY OF IBM                           *
      *                                                                *
      * "RESTRICTED MATERIALS OF IBM"                                  *
      *                                                                *
      * CB12                                                           *
      *                                                                *
      * (C) COPYRIGHT IBM CORP. 2011, 2013 ALL RIGHTS RESERVED         *
      *                                                                *
      * US GOVERNMENT USERS RESTRICTED RIGHTS - USE, DUPLICATION,      *
      * OR DISCLOSURE RESTRICTED BY GSA ADP SCHEDULE                   *
      * CONTRACT WITH IBM CORPORATION                                  *
      *                                                                *
      ******************************************************************
      *               COPYBOOK for Policy details                      *
      *                                                                *
      *   Structures to map values obtained from DB2 tables:           *
      *   Customer, Policy, Endowment, House and Motor.                *
      *                                                                *
      *   All lengths of policy fields will be defined here so that    *
      *   if any of the DB2 table contents change the lengths will     *
      *   only need to be changed here.                                *
      *                                                                *
      ******************************************************************
      
      ******************************************************************
      * DCLGEN TABLE(GENASA1.POLICY)                                   *
      *        LIBRARY(WFEZZAN.GENAPP.DCLGEN)                          *
      *        LANGUAGE(COBOL)                                         *
      *        QUOTE                                                   *
      * ... IS THE DCLGEN COMMAND THAT MADE THE FOLLOWING STATEMENTS   *
      ******************************************************************
           EXEC SQL DECLARE GENASA1.POLICY TABLE
           ( POLICYNUMBER                   INTEGER NOT NULL,
             CUSTOMERNUMBER                 INTEGER NOT NULL,
             ISSUEDATE                      DATE,
             EXPIRYDATE                     DATE,
             POLICYTYPE                     CHAR(1),
             LASTCHANGED                    TIMESTAMP NOT NULL,
             BROKERID                       INTEGER,
             BROKERSREFERENCE               CHAR(10),
             PAYMENT                        INTEGER,
             COMMISSION                     SMALLINT
           ) END-EXEC.
           
       01  WS-POLICY-LENGTHS.
           03 WS-CUSTOMER-LEN          PIC S9(4) COMP VALUE +72.
           03 WS-POLICY-LEN            PIC S9(4) COMP VALUE +72.
           03 WS-ENDOW-LEN             PIC S9(4) COMP VALUE +52.
           03 WS-HOUSE-LEN             PIC S9(4) COMP VALUE +58.
           03 WS-MOTOR-LEN             PIC S9(4) COMP VALUE +65.
           03 WS-COMM-LEN              PIC S9(4) COMP VALUE +1102.
           03 WS-CLAIM-LEN             PIC S9(4) COMP VALUE +546.
           03 WS-FULL-ENDOW-LEN        PIC S9(4) COMP VALUE +124.
           03 WS-FULL-HOUSE-LEN        PIC S9(4) COMP VALUE +130.
           03 WS-FULL-MOTOR-LEN        PIC S9(4) COMP VALUE +137.
           03 WS-FULL-COMM-LEN         PIC S9(4) COMP VALUE +1174.
           03 WS-FULL-CLAIM-LEN        PIC S9(4) COMP VALUE +618.
           03 WS-SUMRY-ENDOW-LEN       PIC S9(4) COMP VALUE +25.

       01  DB2-CUSTOMER.
           03 DB2-FIRSTNAME            PIC X(10).
           03 DB2-LASTNAME             PIC X(20).
           03 DB2-DATEOFBIRTH          PIC X(10).
           03 DB2-HOUSENAME            PIC X(20).
           03 DB2-HOUSENUMBER          PIC X(4).
           03 DB2-POSTCODE             PIC X(8).
           03 DB2-PHONE-MOBILE         PIC X(20).
           03 DB2-PHONE-HOME           PIC X(20).
           03 DB2-EMAIL-ADDRESS        PIC X(100).

       01  DB2-POLICY.
           03 DB2-POLICYTYPE           PIC X.
           03 DB2-POLICYNUMBER         PIC 9(10).
           03 DB2-POLICY-COMMON.
              05 DB2-ISSUEDATE         PIC X(10).
              05 DB2-EXPIRYDATE        PIC X(10).
              05 DB2-LASTCHANGED       PIC X(26).
              05 DB2-BROKERID          PIC 9(10).
              05 DB2-BROKERSREF        PIC X(10).
              05 DB2-PAYMENT           PIC 9(6).

       01  DB2-ENDOWMENT.
           03 DB2-ENDOW-FIXED.
              05 DB2-E-WITHPROFITS      PIC X.
              05 DB2-E-EQUITIES         PIC X.
              05 DB2-E-MANAGEDFUND      PIC X.
              05 DB2-E-FUNDNAME         PIC X(10).
              05 DB2-E-TERM             PIC 9(2).
              05 DB2-E-SUMASSURED       PIC 9(6).
              05 DB2-E-LIFEASSURED      PIC X(31).
           03 DB2-E-PADDINGDATA         PIC X(32611).

       01  DB2-HOUSE.
           03 DB2-H-PROPERTYTYPE       PIC X(15).
           03 DB2-H-BEDROOMS           PIC 9(3).
           03 DB2-H-VALUE              PIC 9(8).
           03 DB2-H-HOUSENAME          PIC X(20).
           03 DB2-H-HOUSENUMBER        PIC X(4).
           03 DB2-H-POSTCODE           PIC X(8).

       01  DB2-MOTOR.
           03 DB2-M-MAKE               PIC X(15).
           03 DB2-M-MODEL              PIC X(15).
           03 DB2-M-VALUE              PIC 9(6).
           03 DB2-M-REGNUMBER          PIC X(7).
           03 DB2-M-COLOUR             PIC X(8).
           03 DB2-M-CC                 PIC 9(4).
           03 DB2-M-MANUFACTURED       PIC X(10).
           03 DB2-M-PREMIUM            PIC 9(6).
           03 DB2-M-ACCIDENTS          PIC 9(6).

       01  DB2-COMMERCIAL.
           03 DB2-B-Address            PIC X(255).
           03 DB2-B-Postcode           PIC X(8).
           03 DB2-B-Latitude           PIC X(11).
           03 DB2-B-Longitude          PIC X(11).
           03 DB2-B-Customer           PIC X(255).
           03 DB2-B-PropType           PIC X(255).
           03 DB2-B-FirePeril          PIC 9(4).
           03 DB2-B-FirePremium        PIC 9(8).
           03 DB2-B-CrimePeril         PIC 9(4).
           03 DB2-B-CrimePremium       PIC 9(8).
           03 DB2-B-FloodPeril         PIC 9(4).
           03 DB2-B-FloodPremium       PIC 9(8).
           03 DB2-B-WeatherPeril       PIC 9(4).
           03 DB2-B-WeatherPremium     PIC 9(8).
           03 DB2-B-Status             PIC 9(4).
           03 DB2-B-RejectReason       PIC X(255).

       01  DB2-CLAIM.
           03 DB2-C-Num                PIC 9(10).
           03 DB2-C-Date               PIC X(10).
           03 DB2-C-Paid               PIC 9(8).
           03 DB2-C-Value              PIC 9(8).
           03 DB2-C-Cause              PIC X(255).
           03 DB2-C-Observations       PIC X(255).
      * end of expanded file: C:\data\GenApp\Copybooks\LGPOLICY.cpy at LGTESTC1.cbl line 112




      *----------------------------------------------------------------*
      *****************************************************************
       PROCEDURE DIVISION.

      *---------------------------------------------------------------*
       MAINLINE SECTION.

           IF EIBCALEN > 0
              GO TO A-GAIN.

           Initialize SSMAPC1I.
           Initialize SSMAPC1O.
           Initialize COMM-AREA.
           MOVE '0000000000'   To ENT1CNOO

      * Display Main Menu
           EXEC CICS SEND MAP ('SSMAPC1')
                     FROM(SSMAPC1O)
                     MAPSET ('SSMAP')
                     ERASE
                     END-EXEC.

       A-GAIN.

           EXEC CICS HANDLE AID
                     CLEAR(CLEARIT)
                     PF3(ENDIT) END-EXEC.
           EXEC CICS HANDLE CONDITION
                     MAPFAIL(ENDIT)
                     END-EXEC.

           EXEC CICS RECEIVE MAP('SSMAPC1')
                     INTO(SSMAPC1I) ASIS
                     MAPSET('SSMAP') END-EXEC.


           EVALUATE ENT1OPTO

             WHEN '1'
                 Move '01ICUS'   To CA-REQUEST-ID
                 Move ENT1CNOO   To CA-CUSTOMER-NUM
      *          EXEC CICS LINK PROGRAM('LGICUS01')
      *                    COMMAREA(COMM-AREA)
      *                    LENGTH(32500)
      *          END-EXEC

                 IF CA-RETURN-CODE > 0
                   GO TO NO-DATA
                 END-IF

                 Move CA-FIRST-NAME to ENT1FNAI
                 Move CA-LAST-NAME  to ENT1LNAI
                 Move CA-DOB        to ENT1DOBI
                 Move CA-HOUSE-NAME to ENT1HNMI
                 Move CA-HOUSE-NUM  to ENT1HNOI
                 Move CA-POSTCODE   to ENT1HPCI
                 Move CA-PHONE-HOME    to ENT1HP1I
                 Move CA-PHONE-MOBILE  to ENT1HP2I
                 Move CA-EMAIL-ADDRESS to ENT1HMOI
                 EXEC CICS SEND MAP ('SSMAPC1')
                           FROM(SSMAPC1O)
                           MAPSET ('SSMAP')
                 END-EXEC
                 GO TO ENDIT-STARTIT

             WHEN '2'
                 Move '01ACUS'   To CA-REQUEST-ID
                 Move 0          To CA-CUSTOMER-NUM
                 Move ENT1FNAI   To CA-FIRST-NAME
                 Move ENT1LNAI   To CA-LAST-NAME
                 Move ENT1DOBI   To CA-DOB
                 Move ENT1HNMI   To CA-HOUSE-NAME
                 Move ENT1HNOI   To CA-HOUSE-NUM
                 Move ENT1HPCI   To CA-POSTCODE
                 Move ENT1HP1I   To CA-PHONE-HOME
                 Move ENT1HP2I   To CA-PHONE-MOBILE
                 Move ENT1HMOI   To CA-EMAIL-ADDRESS
                 Inspect COMM-AREA Replacing All x'00'  by x'40'
                 Move Function UPPER-CASE(CA-POSTCODE)
                      TO CA-POSTCODE

      *          EXEC CICS LINK PROGRAM('LGACUS01')
      *                    COMMAREA(COMM-AREA)
      *                    LENGTH(32500)
      *          END-EXEC

                 PERFORM READ-LOGIC

                 IF CA-RETURN-CODE > 0
                   Exec CICS Syncpoint Rollback End-Exec
                   GO TO NO-ADD
                 END-IF

                 Perform WRITE-GENACNTL
                 Move CA-CUSTOMER-NUM To ENT1CNOI
                 Move ' '             To ENT1OPTI
                 Move 'New Customer Inserted'
                   To  ERRFLDO
                 EXEC CICS SEND MAP ('SSMAPC1')
                           FROM(SSMAPC1O)
                           MAPSET ('SSMAP')
                 END-EXEC
                 GO TO ENDIT-STARTIT

             WHEN '4'
                 Move '01ICUS'   To CA-REQUEST-ID
                 Move ENT1CNOO   To CA-CUSTOMER-NUM
      *          EXEC CICS LINK PROGRAM('LGICUS01')
      *                    COMMAREA(COMM-AREA)
      *                    LENGTH(32500)
      *          END-EXEC

                 PERFORM READ-LOGIC

                 IF CA-RETURN-CODE > 0
                   GO TO NO-DATA
                 END-IF

                 Move CA-FIRST-NAME to ENT1FNAI
                 Move CA-LAST-NAME  to ENT1LNAI
                 Move CA-DOB        to ENT1DOBI
                 Move CA-HOUSE-NAME to ENT1HNMI
                 Move CA-HOUSE-NUM  to ENT1HNOI
                 Move CA-POSTCODE   to ENT1HPCI
                 Move CA-PHONE-HOME    to ENT1HP1I
                 Move CA-PHONE-MOBILE  to ENT1HP2I
                 Move CA-EMAIL-ADDRESS to ENT1HMOI
                 EXEC CICS SEND MAP ('SSMAPC1')
                           FROM(SSMAPC1O)
                           MAPSET ('SSMAP')
                 END-EXEC
                 EXEC CICS RECEIVE MAP('SSMAPC1')
                           INTO(SSMAPC1I) ASIS
                           MAPSET('SSMAP') END-EXEC

                 Move '01UCUS'   To CA-REQUEST-ID
                 Move ENT1CNOI   To CA-CUSTOMER-NUM
                 Move ENT1FNAI   To CA-FIRST-NAME
                 Move ENT1LNAI   To CA-LAST-NAME
                 Move ENT1DOBI   To CA-DOB
                 Move ENT1HNMI   To CA-HOUSE-NAME
                 Move ENT1HNOI   To CA-HOUSE-NUM
                 Move ENT1HPCI   To CA-POSTCODE
                 Move ENT1HP1I   To CA-PHONE-HOME
                 Move ENT1HP2I   To CA-PHONE-MOBILE
                 Move ENT1HMOI   To CA-EMAIL-ADDRESS
                 Inspect COMM-AREA Replacing All x'00'  by x'40'
                 Move Function UPPER-CASE(CA-POSTCODE)
                      TO CA-POSTCODE
                 EXEC CICS LINK PROGRAM('LGUCUS01')
                           COMMAREA(COMM-AREA)
                           LENGTH(32500)
                 END-EXEC

                 IF CA-RETURN-CODE > 0
                   GO TO NO-UPD
                 END-IF

                 Move CA-CUSTOMER-NUM To ENT1CNOI
                 Move ' '             To ENT1OPTI
                 Move 'Customer details updated'
                   To  ERRFLDO
                 EXEC CICS SEND MAP ('SSMAPC1')
                           FROM(SSMAPC1O)
                           MAPSET ('SSMAP')
                 END-EXEC
                 GO TO ENDIT-STARTIT

             WHEN OTHER

                 Move 'Please enter a valid option'
                   To  ERRFLDO
                 Move -1 To ENT1OPTL

                 EXEC CICS SEND MAP ('SSMAPC1')
                           FROM(SSMAPC1O)
                           MAPSET ('SSMAP')
                           CURSOR
                 END-EXEC
                 GO TO ENDIT-STARTIT

           END-EVALUATE.


      *    Send message to terminal and return

           EXEC CICS RETURN
           END-EXEC.

       ENDIT-STARTIT.
           EXEC CICS RETURN
                TRANSID('SSC1')
                COMMAREA(COMM-AREA)
                END-EXEC.

       ENDIT.
           EXEC CICS SEND TEXT
                     FROM(MSGEND)
                     LENGTH(LENGTH OF MSGEND)
                     ERASE
                     FREEKB
           END-EXEC
           EXEC CICS RETURN
           END-EXEC.

       CLEARIT.

           Initialize SSMAPC1I.
           EXEC CICS SEND MAP ('SSMAPC1')
                     MAPSET ('SSMAP')
                     MAPONLY
           END-EXEC

           EXEC CICS RETURN
                TRANSID('SSC1')
                COMMAREA(COMM-AREA)
                END-EXEC.

       NO-UPD.
           Move 'Error Updating Customer'          To  ERRFLDO.
           Go To ERROR-OUT.

       NO-ADD.
           Move 'Error Adding Customer'            To  ERRFLDO.
           Go To ERROR-OUT.

       NO-DATA.
           Move 'No data was returned.'            To  ERRFLDO.
           Go To ERROR-OUT.

       ERROR-OUT.
           EXEC CICS SEND MAP ('SSMAPC1')
                     FROM(SSMAPC1O)
                     MAPSET ('SSMAP')
           END-EXEC.

           Initialize SSMAPC1I.
           Initialize SSMAPC1O.
           Initialize COMM-AREA.

           GO TO ENDIT-STARTIT.
      *--------------------------------------------------------------*
       READ-LOGIC.
           INITIALIZE WS-HEADER.
      *
           MOVE EIBTRNID TO WS-TRANSID.
           MOVE EIBTRMID TO WS-TERMID.
           MOVE EIBTASKN TO WS-TASKNUM.
      *----------------------------------------------------------------*
      * Check commarea and obtain required details                     *
      *----------------------------------------------------------------*
           IF EIBCALEN IS EQUAL TO ZERO
               MOVE ' NO COMMAREA RECEIVED' TO EM-VARIABLE
               PERFORM WRITE-ERROR-MESSAGE
               EXEC CICS ABEND ABCODE('LGCA') NODUMP END-EXEC
           END-IF

           MOVE '00' TO CA-RETURN-CODE
           MOVE '00' TO CA-NUM-POLICIES
           MOVE EIBCALEN TO WS-CALEN.
           SET WS-ADDR-DFHCOMMAREA TO ADDRESS OF COMM-AREA.

      *----------------------------------------------------------------*
      * Process incoming commarea                                      *
      *----------------------------------------------------------------*
      * check commarea length
           MOVE WS-CUSTOMER-LEN        TO WS-REQUIRED-CA-LEN
           ADD WS-CA-HEADERTRAILER-LEN TO WS-REQUIRED-CA-LEN
           IF EIBCALEN IS LESS THAN WS-REQUIRED-CA-LEN
             MOVE '98' TO CA-RETURN-CODE
             EXEC CICS RETURN END-EXEC
           END-IF

           MOVE CA-CUSTOMER-NUM TO EM-CUSNUM

           PERFORM GET-CUSTOMER-INFO.

       GET-CUSTOMER-INFO.

           Move 0 To MQ-Hit
           Exec CICS ReadQ TS Queue(MQ-Control)
                     Into(MQ-Read-Record)
                     Resp(WS-RESP)
                     Item(1)
           End-Exec.
           If WS-RESP = DFHRESP(NORMAL)
              Perform With Test after Until WS-RESP > 0
                 Exec CICS ReadQ TS Queue(MQ-Control)
                     Into(MQ-Read-Record)
                     Resp(WS-RESP)
                     Next
                 End-Exec
                 If WS-RESP = DFHRESP(NORMAL) And
                      MQ-Read-Record(1:6) = 'MQHIT='
                      Move 1 To MQ-Hit
                 End-If
              End-Perform
           End-If.

           If MQ-Hit = 0
             EXEC CICS LINK Program(LGICDB01)
                 Commarea(COMM-AREA)
                 LENGTH(32500)
             END-EXEC
           Else
             EXEC CICS LINK Program('AAAAAAAA')
                 Commarea(COMM-AREA)
                 LENGTH(32500)
             END-EXEC
           End-If.

           EXIT.

      *================================================================*
      * Procedure to write error message to Queues                     *
      *   message will include Date, Time, Program Name, Customer      *
      *   Number, Policy Number and SQLCODE.                           *
      *================================================================*
       WRITE-ERROR-MESSAGE.
      * Obtain and format current time and date
           EXEC CICS ASKTIME ABSTIME(WS-ABSTIME)
           END-EXEC
           EXEC CICS FORMATTIME ABSTIME(WS-ABSTIME)
                     MMDDYYYY(WS-DATE)
                     TIME(WS-TIME)
           END-EXEC
           MOVE WS-DATE TO EM-DATE
           MOVE WS-TIME TO EM-TIME
      * Write output message to TDQ
           EXEC CICS LINK PROGRAM('LGSTSQ')
                     COMMAREA(ERROR-MSG)
                     LENGTH(LENGTH OF ERROR-MSG)
           END-EXEC.
      * Write 90 bytes or as much as we have of commarea to TDQ
           IF EIBCALEN > 0 THEN
             IF EIBCALEN < 91 THEN
               MOVE COMM-AREA(1:EIBCALEN) TO CA-DATA
               EXEC CICS LINK PROGRAM('LGSTSQ')
                         COMMAREA(CA-ERROR-MSG)
                         LENGTH(LENGTH OF CA-ERROR-MSG)
               END-EXEC
             ELSE
               MOVE COMM-AREA(1:90) TO CA-DATA
               EXEC CICS LINK PROGRAM('LGSTSQ')
                         COMMAREA(CA-ERROR-MSG)
                         LENGTH(LENGTH OF CA-ERROR-MSG)
               END-EXEC
             END-IF
           END-IF.
           EXIT.


       WRITE-GENACNTL.

           EXEC CICS ENQ Resource(STSQ-NAME)
                         Length(Length Of STSQ-NAME)
           END-EXEC.
           Move 'Y' To WS-FLAG-TSQH
           Move 1   To WS-Item-Count
           Exec CICS ReadQ TS Queue(STSQ-NAME)
                     Into(READ-MSG)
                     Resp(WS-RESP)
                     Item(1)
           End-Exec.
           If WS-RESP = DFHRESP(NORMAL)
              Perform With Test after Until WS-RESP > 0
                 Exec CICS ReadQ TS Queue(STSQ-NAME)
                     Into(READ-MSG)
                     Resp(WS-RESP)
                     Next
                 End-Exec
                 Add 1 To WS-Item-Count
                 If WS-RESP = DFHRESP(NORMAL) And
                      Read-Msg-Msg(1:13) = 'HIGH CUSTOMER'
                      Move CA-Customer-Num To Write-Msg-High
                      Move Space to WS-FLAG-TSQH
                      Exec CICS WriteQ TS Queue(STSQ-NAME)
                          From(Write-Msg-H)
                          Length(F24)
                          Resp(WS-RESP)
                          ReWrite
                          Item(WS-Item-Count)
                      End-Exec
                      MOVE 99 To WS-RESP
                 End-If
              End-Perform
           End-If.
      *
      *
           If WS-FLAG-TSQH = 'Y'
             EXEC CICS WRITEQ TS QUEUE(STSQ-NAME)
                       FROM(WRITE-MSG-E)
                       RESP(WS-RESP)
                       NOSUSPEND
                       LENGTH(20)
             END-EXEC
             Move CA-Customer-Num To Write-Msg-Low
             Move CA-Customer-Num To Write-Msg-High
             EXEC CICS WRITEQ TS QUEUE(STSQ-NAME)
                       FROM(WRITE-MSG-L)
                       RESP(WS-RESP)
                       NOSUSPEND
                       LENGTH(23)
             END-EXEC
             EXEC CICS WRITEQ TS QUEUE(STSQ-NAME)
                       FROM(WRITE-MSG-H)
                       RESP(WS-RESP)
                       NOSUSPEND
                       LENGTH(24)
             END-EXEC
           End-If.

           EXEC CICS DEQ Resource(STSQ-NAME)
                         Length(Length Of STSQ-NAME)
           END-EXEC.

           EXIT.
